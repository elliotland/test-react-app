'use client'
import { useState } from "react";
export default function Page() {

  return (
    <div>
      <h1>Hello</h1>
    </div>
  )
}
