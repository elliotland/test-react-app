import { useState } from "react";

export default function Navbar() {
  return (
    <div className="ui inverted menu">
          <a className="header item" href="/">
    Home
  </a>
    </div>
  )
}