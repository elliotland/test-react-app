import { useState } from "react";
type ContainerProps = {
    children: React.ReactNode; //👈 children prop typr
    className: string;
  };
  
export default function Grid(props: ContainerProps) {
  return (
    <div className="ui grid">
    </div>
  )
}