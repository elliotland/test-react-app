import { useState } from "react";
type ContainerProps = {
    children: React.ReactNode; //👈 children prop type
    className: string;
  };
  
export default function Column(props: ContainerProps) {
  return (
    <div className="ui Column">
    </div>
  )
}