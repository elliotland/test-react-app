import { useState } from "react";
type ContainerProps = {
  children: React.ReactNode; //👈 children prop typr
  className: string;
};

export default function Container(props: ContainerProps) {
  return (
    <div className="ui container">
    </div>
  )
}